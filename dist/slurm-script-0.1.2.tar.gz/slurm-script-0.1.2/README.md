# `slurm_script` Python Slurm command generator

This package is designed to generate slurm script to submit `mpi` jobs to a cluster.
